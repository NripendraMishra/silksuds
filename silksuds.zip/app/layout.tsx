import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { AuthProvider } from '../context/AuthContext'
import { CartProvider } from '../context/CartContext';
import AnalyticsTracker from '../components/AnalyticsTracker';

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Devbhojya - Fresh Milled Cold-Pressed Atta',
  description: 'Experience the difference of fresh-milled, cold-pressed flour. Traditional grinding with modern hygiene standards.',
  keywords: 'atta, flour, cold-pressed, millet, organic, healthy, devbhojya',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <AuthProvider>
          <CartProvider>
            <AnalyticsTracker />
            <Header />
            <main className="min-h-screen">
              {children}
            </main>
            <Footer />
          </CartProvider>
        </AuthProvider>
      </body>
    </html>
  )
}
