"use client"
import React, { useEffect, useState } from 'react'
import Link from 'next/link'
import { Star, ShoppingCart } from 'lucide-react'
import Image from 'next/image'
import { useRouter } from 'next/navigation'

interface Product {
  id: number
  name: string
  price: number
  image: string
  description: string
  slug: string
}

const HomePage = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const router = useRouter();

  useEffect(() => {
    fetch('/products.json')
      .then(res => res.json())
      .then(data => setProducts(data));
  }, []);

  // Get products with id 2, 3, 4
  const bestSellers = products.filter(
    (p) => p.id === 2 || p.id === 3 || p.id === 4
  );

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="gradient-bg py-20 lg:py-32">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h1 className="text-4xl lg:text-6xl font-bold text-gray-800 leading-tight">
                Fresh Milled <span className="text-accent-600">Cold-Pressed</span> Atta
              </h1>
              <p className="text-xl text-gray-600 max-w-lg">
                Taste the goodness of traditional grinding with modern hygiene standards. 
                Experience the difference of fresh-milled, cold-pressed flour.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/shop" className="btn btn-primary">
                  SHOP NOW
                </Link>
                <Link href="/about" className="btn btn-outline">
                  Learn More
                </Link>
              </div>
            </div>
            <div className="relative">
              <div className="aspect-square bg-white rounded-full shadow-2xl flex items-center justify-center">
                <div className="text-center">
                  <div className="text-6xl mb-4">🌾</div>
                  <h3 className="text-2xl font-bold text-gray-800">100% Pure</h3>
                  <p className="text-gray-600">Cold-Pressed Atta</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Best Sellers Section */}
      <section className="section-padding">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-800 mb-4">BEST SELLERS</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our most popular products, loved by families across India
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {bestSellers.map((product) => (
              <div
                key={product.id}
                className="card cursor-pointer hover:shadow-xl transition"
                onClick={() => router.push(`/product/${product.slug}`)}
              >
                <div className="aspect-square bg-gradient-to-br from-orange-100 to-orange-200 flex items-center justify-center overflow-hidden">
                  {product.image ? (
                    <Image
                      src={product.image}
                      alt={product.name}
                      width={200}
                      height={200}
                      className="object-cover"
                    />
                  ) : (
                    <div className="text-6xl">🌾</div>
                  )}
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-800 mb-2">{product.name}</h3>
                  <p className="text-gray-600 mb-4">{product.description}</p>
                  <div className="flex items-center justify-end">
                    <button
                      className="btn btn-secondary"
                      onClick={e => { e.stopPropagation(); router.push(`/product/${product.slug}`); }}
                    >
                      <ShoppingCart className="w-4 h-4 mr-2" />
                      View Details
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section className="section-padding bg-gray-50">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-800 mb-4">TOP REVIEWS</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              What our customers say about our products
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Review 1 */}
            <div className="bg-white rounded-lg p-6 shadow-md">
              <div className="flex items-center mb-4">
                <div className="flex text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-current" />
                  ))}
                </div>
                <span className="ml-2 text-gray-600 font-medium">5/5</span>
              </div>
              <p className="text-gray-700 mb-4">
                "I have started using millet flours of Devbhojya. They are amazing and boon for winters. 
                I used in my family - Bajra Atta, Jowar Atta, Makka Atta and Ragi Ratan Flour. 
                Cold press atta is healthy as per Ayurveda. I love my family so I love Devbhojya."
              </p>
              <cite className="text-accent-600 font-medium">- Deepika Pandey</cite>
            </div>

            {/* Review 2 */}
            <div className="bg-white rounded-lg p-6 shadow-md">
              <div className="flex items-center mb-4">
                <div className="flex text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-current" />
                  ))}
                </div>
                <span className="ml-2 text-gray-600 font-medium">5/5</span>
              </div>
              <p className="text-gray-700 mb-4">
                "I use Multigrain Flour of Devbhojya, it's better than other multigrains in market 
                because it has more multigrains compared to other brands in market. 
                I have seen the facilities at factory and I find it hygienic and best suitable for my family."
              </p>
              <cite className="text-accent-600 font-medium">- Manraj Singh</cite>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding">
        <div className="container">
          <div className="bg-gradient-to-r from-accent-600 to-secondary-600 rounded-2xl p-8 lg:p-12 text-white text-center">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">Taste the Goodness!</h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto">
              Experience the difference of fresh-milled, cold-pressed flour. 
              Order now and taste the authentic flavors of traditional grinding.
            </p>
            <Link href="/shop" className="btn bg-white text-accent-600 hover:bg-gray-100 text-lg px-8 py-4">
              SHOP NOW
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}

export default HomePage
