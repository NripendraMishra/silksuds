// Import the functions you need from the SDKs you need
import { initializeApp, getApps, FirebaseApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth as firebaseGetAuth } from "firebase/auth";
import { getAnalytics, Analytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyCCDChZgW6oODwPqRtDT7za_PKQE59jaqQ",
    authDomain: "devbhojya-b3fda.firebaseapp.com",
    projectId: "devbhojya-b3fda",
    storageBucket: "devbhojya-b3fda.firebasestorage.app",
    messagingSenderId: "122066315201",
    appId: "1:122066315201:web:a62b1fbbb91df141da7140",
    measurementId: "G-FKWF3FLZ1V"
};

export const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = firebaseGetAuth(app);

// Initialize Analytics only on client side
let analytics: Analytics;
if (typeof window !== 'undefined') {
    analytics = getAnalytics(app);
}

export { analytics };
export const GA_TRACKING_ID = 'G-FKWF3FLZ1V'; // Use your Firebase measurementId